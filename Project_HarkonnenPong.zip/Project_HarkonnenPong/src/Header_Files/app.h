/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef APP_H
#define APP_H

#include "cmu.h"
#include "gpio.h"
#include "capsense.h"
#include "queue.h"
#include "em_emu.h"

#define SPEED_TASK_STACK_SIZE 512
#define DIRECTION_TASK_STACK_SIZE 512
#define MONITOR_TASK_STACK_SIZE 512
#define LED_TASK_STACK_SIZE 512
#define LCD_TASK_STACK_SIZE 512
#define IDLE_TASK_STACK_SIZE 512

#define SPEED_SETPOINT_TASK_PRIO            21
#define VEHICLE_DIRECTION_TASK_PRIO         22
#define VEHICLE_MONITOR_TASK_PRIO           23
#define LED_TASK_PRIO                       24
#define LCD_TASK_PRIO                       25
#define IDLE_TASK_PRIO                      26

enum DATA_FLAGS{
  SPEEDCHANGE = 1,
  DIRECTIONCHANGE = 2,
  MONITORBITMASK = 3,
};
enum ALERT_FLAGS{
  ALERT0 = 1,
  ALERT1 = 2,
  ALERTBITMASK = 3,
};

struct speed_t {

    /// 0 is unpressed 1 is pressed
    int mph;
    uint32_t increments;
    uint32_t decrements;
};
struct direction_t {

    /// 0 is unpressed 1 is pressed
  bool straight;
  int direction;
  bool sharp_angle;
  uint32_t left_turns;
  uint32_t right_turns;
  uint32_t time_count;
};

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void);
void lab2_init(void);
void read_button0(void);
void read_button1(void);
void read_capsense(void);
void App_TimerCallback(void  *p_tmr, void  *p_arg);

#endif  // APP_H
