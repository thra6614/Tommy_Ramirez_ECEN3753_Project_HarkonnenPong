/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include "app.h"
#include "blink.h"
#include "os.h"
#include "glib.h"
#include "dmd.h"
//#include "sl_board_control.h"
//#include "sl_simple_button_instances.h"

static bool btn0press = false;
static bool btn1press = false;
static bool cap_state = false;
static int cap_count = 0;
static bool cap_valid = false;

static OS_TCB tcb_new_hm;
static CPU_STK stack_new_hm[NEW_HM_TASK_STACK_SIZE];
static OS_TCB tcb_direction;
static CPU_STK stack_direction[DIRECTION_TASK_STACK_SIZE];
static OS_TCB tcb_monitor;
static CPU_STK stack_monitor[MONITOR_TASK_STACK_SIZE];
static OS_TCB tcb_physics;
static CPU_STK stack_physics[PHYSICS_TASK_STACK_SIZE];
static OS_TCB tcb_led_pwm;
static CPU_STK stack_led_pwm[LED_PWM_TASK_STACK_SIZE];
static OS_TCB tcb_led;
static CPU_STK stack_led[LED_TASK_STACK_SIZE];
static OS_TCB tcb_lcd;
static CPU_STK stack_lcd[LCD_TASK_STACK_SIZE];
static OS_TCB tcb_idle;
static CPU_STK stack_idle[IDLE_TASK_STACK_SIZE];

static OS_FLAG_GRP  App_Flags1;
//static OS_FLAG_GRP  App_Flags2;
static OS_TMR  App_Timer_LCD;
static OS_TMR  App_Timer_Physics;
static OS_SEM  App_Semaphore_LCD;
static OS_SEM  App_Semaphore_Physics;
static OS_MUTEX  App_Mutex1;
static OS_MUTEX  App_Mutex2;
static void new_hm_task(void *arg);
static void physics_task(void *arg);
static void direction_task(void *arg);
static void monitor_task(void *arg);
static void led_pwm_task(void *arg);
static void led_task(void *arg);
static void lcd_task(void *arg);
static void idle_task(void *arg);

struct init_variables var_init = {3,10,10,9800,100000,{3,7000,0,{0,0},50000,{0,0,0,0,0,0,0,0}},{2000000,100,2000,{true,false,0},false}, {70,{40,500,1000}},{1,false}};
struct object_t platform = {64000, 100, 0, 0, 100, true};
struct object_t HM = {50000, 0, 0, 0, 0, false};

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
  gpio_open();
  blink_init();

  //default_init();
  lab2_init();
}
void default_init(void)
{
  platform.mass = var_init.Plat.mass;
  HM.xpos = var_init.HM.initx/10;
  HM.xvel = -50000;//var_init.HM.initial_velocity.xvel;
  HM.yvel = var_init.HM.initial_velocity.yvel;
}
void App_TimerCallbackPhysics(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_Physics,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void App_TimerCallbackLCD(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_LCD,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void lab2_init(void)
{
  RTOS_ERR err;

  // Create Blink Task
  OSTaskCreate(&tcb_idle,
               "idle task",
                idle_task,
                DEF_NULL,
                IDLE_TASK_PRIO,
               &stack_idle[0],
                (IDLE_TASK_STACK_SIZE / 10u),
                IDLE_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_new_hm,
               "NEW HM Task",
                new_hm_task,
                DEF_NULL,
                NEW_HM_TASK_PRIO,
               &stack_new_hm[0],
                (NEW_HM_TASK_STACK_SIZE / 10u),
                NEW_HM_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_physics,
               "Physics Task",
                physics_task,
                DEF_NULL,
                PHYSICS_TASK_PRIO,
               &stack_physics[0],
                (PHYSICS_TASK_STACK_SIZE / 10u),
                PHYSICS_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_direction,
               "Platform Direction Task",
                direction_task,
                DEF_NULL,
                PLATFORM_DIRECTION_TASK_PRIO,
               &stack_direction[0],
                (DIRECTION_TASK_STACK_SIZE / 10u),
                DIRECTION_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_monitor,
               "Collision Monitor Task",
                monitor_task,
                DEF_NULL,
                COLLISION_MONITOR_TASK_PRIO,
               &stack_monitor[0],
                (MONITOR_TASK_STACK_SIZE / 10u),
                MONITOR_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_led_pwm,
                 "led pwm control task",
                 led_pwm_task,
                  DEF_NULL,
                  LED_PWM_TASK_PRIO,
                 &stack_led_pwm[0],
                  (LED_PWM_TASK_STACK_SIZE / 10u),
                  LED_PWM_TASK_STACK_SIZE,
                  0u,
                  0u,
                  DEF_NULL,
                  (OS_OPT_TASK_STK_CLR),
                 &err);
  OSTaskCreate(&tcb_led,
               "led task",
               led_task,
                DEF_NULL,
                LED_TASK_PRIO,
               &stack_led[0],
                (LED_TASK_STACK_SIZE / 10u),
                LED_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_lcd,
               "lcd task",
               lcd_task,
                DEF_NULL,
                LCD_TASK_PRIO,
               &stack_lcd[0],
                (LCD_TASK_STACK_SIZE / 10u),
                LCD_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTmrCreate(&App_Timer_Physics,                 /*   Pointer to user-allocated timer.         */
              "App Timer Physics",                /*   Name used for debugging.                 */
               var_init.TauPhysics,               /*     initial delay.                       */
               var_init.TauPhysics,               /*   10 Timer Ticks period.                  */
               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
               App_TimerCallbackPhysics,         /*   Called when timer expires.               */
               DEF_NULL,                  /*   No arguments to callback.                */
              &err);
  OSTmrCreate(&App_Timer_LCD,                 /*   Pointer to user-allocated timer.         */
              "App Timer LCD",                /*   Name used for debugging.                 */
               var_init.TauLCD,               /*     initial delay.                       */
               var_init.TauLCD,               /*   10 Timer Ticks period.                  */
               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
               App_TimerCallbackLCD,         /*   Called when timer expires.               */
               DEF_NULL,                  /*   No arguments to callback.                */
              &err);
  OSFlagCreate(&App_Flags1,                /*   Pointer to user-allocated event flag.    */
               "App Flags1",               /*   Name used for debugging.                 */
                0,                        /*   Initial flags, all cleared.              */
               &err);
//  OSFlagCreate(&App_Flags2,                /*   Pointer to user-allocated event flag.    */
//               "App Flags2",               /*   Name used for debugging.                 */
//                0,                        /*   Initial flags, all cleared.              */
//               &err);
  OSSemCreate(&App_Semaphore_LCD,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore LCD",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSSemCreate(&App_Semaphore_Physics,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore Physics",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSMutexCreate(&App_Mutex1,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex1",  /*   Name used for debugging.                         */
                &err);
  OSMutexCreate(&App_Mutex2,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex2",  /*   Name used for debugging.                         */
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
static void idle_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    while (1)
    {
        EMU_EnterEM1();
    }
}
static void new_hm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OS_FLAGS flags;
    int refill = var_init.HM.Num;
    int laser_ammo = var_init.laser.NumActivations;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        flags = OSFlagPend(&App_Flags1,        /*   Pointer to user-allocated event flag. */
                            RESET_HM,            /*   Flag bitmask to match.                */
                            0,                      /*   Wait for 100 OS Ticks maximum.        */
                            OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                            OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                            OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                            DEF_NULL,                 /*   Timestamp is not used.                */
                           &err);
        refill--;
        if(flags == LASER)
        {
            if(laser_ammo > 0)
            {
                laser_ammo--;
                OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                                    &err);
                reset_hm(&HM, &refill);
                OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                                     DEF_NULL,              /*   Timestamp is not used.                   */
                                    &err);
            }
        }
    }
}
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OSTmrStart(&App_Timer_Physics,                  /*   Pointer to user-allocated timer.         */
               &err);
    struct object_t HM_Phys;
    while (1)
    {
        OSSemPend(&App_Semaphore_Physics,                 /* Pointer to user-allocated semaphore.    */
                   0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                   OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                   DEF_NULL,                      /* Timestamp is not used.                  */
                  &err);
        OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        HM_Phys = HM;
        OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

        physics(&HM_Phys, 0, var_init.gravity/10, 0);

        OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        HM = HM_Phys;
        OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

    }
}
static void direction_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    CAPSENSE_Init();
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(200, OS_OPT_TIME_DLY, &err);

        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        read_capsense();
        if(cap_valid)
        {
            if(cap_count == 0b1100 || cap_count == 0b0011)
            {
                cap_count = cap_count & 0b1001;
            }
        }
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}
static void monitor_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
    }
}
static void led_pwm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
    }
}
static void led_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    int height = 0;
    int direction;
    int cycle = 0;
    int period = 1;
    int remainder;
    while (1)
    {
          OSTimeDly(10, OS_OPT_TIME_DLY, &err);
          cycle++;
          if((height/1000 > 128) && (cycle % 100 == 0) && cycle > 0)
          {
              GPIO_PinOutToggle(LED0_port, LED0_pin);
              cycle = 0;
          }
          else
          {
              OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                       0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                       OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                       DEF_NULL,              /*   Timestamp is not used.                   */
                      &err);
              height = HM.ypos;
              OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                       OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                      &err);
          }
          OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                       0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                       OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                       DEF_NULL,              /*   Timestamp is not used.                   */
                      &err);
          direction = cap_count;
          OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                       OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                      &err);
          if(direction == 0) period = 1000;
          else if(direction == 1) period = 25;
          else if(direction == 2) period = 50;
          else if(direction == 4) period = 100;
          else if(direction == 8) period = 200;
          remainder = cycle % (period);
          if(remainder == 0)
            GPIO_PinOutToggle(LED1_port, LED1_pin);
//            if(speed_result.mph >= 75 || (speed_result.mph >= 45 && !direction_result.straight)) //btn 0 press
//            {
//                      GPIO_PinOutSet(LED0_port, LED0_pin);
//            }
//            else
//            {
//                GPIO_PinOutClear(LED0_port, LED0_pin);
//            }
//        }
//        if(flags == 2) //slider task
//        {
//            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            direction_result = direction_data;
//            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//            if(direction_result.time_count == 25) //left slider press
//            {
//                GPIO_PinOutSet(LED1_port, LED1_pin);
//            }
//            else
//            {
//                GPIO_PinOutClear(LED1_port, LED1_pin);
//            }
//        }
    }
}
static void lcd_task(void *arg)
    {
        PP_UNUSED_PARAM(arg);
        RTOS_ERR err;
        uint32_t status;
        GLIB_Context_t glibContext;
        //int currentLine = 0;
        /* Enable the memory lcd */
        status = sl_board_enable_display();
        EFM_ASSERT(status == SL_STATUS_OK);

        /* Initialize the DMD support for memory lcd display */
        status = DMD_init(0);
        EFM_ASSERT(status == DMD_OK);

        /* Initialize the glib context */
        status = GLIB_contextInit(&glibContext);
        EFM_ASSERT(status == GLIB_OK);

        glibContext.backgroundColor = White;
        glibContext.foregroundColor = Black;
        /* Fill lcd with background color */

        //static int slower = 0;
        //bool ledon = false;
        int fall = 0;
        GLIB_clear(&glibContext);

        CAPSENSE_Init();

        /* Use Narrow font */
        GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);
        int border = var_init.canyonsize;
        int plat_width = var_init.Plat.length;

        GLIB_Rectangle_t platform;
        GLIB_Rectangle_t canyon;

        //struct object_t plat_LCD;
        struct object_t HM_LCD;
        OSTmrStart(&App_Timer_LCD,                  /*   Pointer to user-allocated timer.         */
                   &err);
        while (1)
        {
//            read_capsense();
//            if(cap_valid)
//            {
//
//                if(cap_count == 0b1100 || cap_count == 0b0011)
//                {
//                    cap_count = cap_count & 0b001001;
//                }
//            }
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            GLIB_clear(&glibContext);

            OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                         DEF_NULL,              /*   Timestamp is not used.                   */
                        &err);
            HM_LCD = HM;
            OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                        &err);

            GLIB_drawCircleFilled(&glibContext, HM_LCD.xpos/1000, HM_LCD.ypos/1000, var_init.HM.DisplayDiameter/2000);
            canyon.xMin = 64-(border/2000);
            canyon.xMax = 0;
            canyon.yMin = 0;
            canyon.yMax = 128;
            GLIB_drawRectFilled(&glibContext, &canyon);

            canyon.xMin = 64+(border/2000);
            canyon.xMax = 128;
            GLIB_drawRectFilled(&glibContext, &canyon);
            platform.xMin = 64 - plat_width/500;
            platform.xMax = 64 + plat_width/500;
            platform.yMin = 100;
            platform.yMax = 101;
            GLIB_drawRectFilled(&glibContext, &platform);



            if(HM_LCD.ypos/1000 >= 123)
            {
                OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
                              LASER,            /*   Application Flag B bitmask.              */
                              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
                             &err);
            }
            if(fall >= 123 && (fall - 123) % 50 == 0)
            {

            }



//            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            direction_result = direction_data;
//            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//                    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//                    GLIB_clear(&glibContext);
//                    if(currentLine == 12)
//                    {
//                        currentLine = 0;
//                    }
//                    char string[100];
//                    sprintf(string, "%d MPH", speed_result.mph);
//                    const char * str1 = string;
//                    GLIB_drawStringOnLine(&glibContext,
//                                           str1,
//                                           currentLine,
//                                           GLIB_ALIGN_LEFT,
//                                           0,
//                                           5,
//                                           true);
//                    if(direction_result.straight)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                              "straight",
//                                              currentLine,
//                                              GLIB_ALIGN_RIGHT,
//                                              0,
//                                              5,
//                                              true);
//                    }
//                    else if(direction_result.direction == 0b0010)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                              "left",
//                                              currentLine,
//                                              GLIB_ALIGN_RIGHT,
//                                              0,
//                                              5,
//                                              true);
//                    }
//                    else if(direction_result.direction == 0b0001)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "hard left",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
//                    else if(direction_result.direction == 0b0100)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "right",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
//                    else if(direction_result.direction == 0b1000)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "hard right",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
                    DMD_updateDisplay();
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }

/***************************************************************************//**
 * @brief
 *   samples pushbutton 0 and sets btn0press to true if button 0 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button0(void)
{
  btn0press = !GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN);
}
/***************************************************************************//**
 * @brief
 *   samples pushbutton 1 and sets btn1press to true if button 1 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button1(void)
{
  btn1press = !GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN);
}
/***************************************************************************//**
 * @brief
 *   Determines the position of a finger on the capacitive touch slider by setting
 *   cap_state to true if the left side is pressed, false if the right side is
 *   pressed, and cap_valid to false if neither or both sides are touched (true if
 *   only one side).
 ******************************************************************************/
void read_capsense(void)
{
  cap_count = 0;
  CAPSENSE_Sense();
  for(int i = 0; i < 4; i++)
  {
      cap_count &= 0 << i;
      cap_count += ((CAPSENSE_getPressed(i) * 1) << i);
  }
  cap_valid = true;
  if((cap_count >= 4) && (cap_count % 4 == 0))
  {
      cap_state = false; //right

  }
  else if((cap_count < 4) && (cap_count > 0))
  {
      cap_state = true; //left
  }
  else //no press or both sides pressed
  {
      cap_valid = false;
  }
}
void physics(struct object_t *object, int xaccelmode, int yaccel, int ke_change) {
    if(xaccelmode == 1)
    {
      object->xvel += 4;
    }
    else if(xaccelmode == 2)
    {
      object->xvel += 1;
    }
    else if(xaccelmode == 4)
    {
      object->xvel -= 1;
    }
    else if(xaccelmode == 8)
    {
      object->xvel -= 4;
    }
    object->xpos += object->xvel;
    if(!object->plat_or_hm)
    {
      object->yvel += yaccel;
      object->ypos += object->yvel;
    }
}
int bounds(struct object_t *object, int plat_hm, int border){
    if(object->ypos > border)
    {
        return 1;
    }
    return 0.0;
}

void reset_hm(struct object_t *object, int *hm_count) {
    (*hm_count)--;
    object->ypos = 0;
    object->yvel = 0;
}
/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB0_PIN);
//  if(is_empty(&btn))
//  {
//      btn = create_queue(10); //10 means btn 0 press (0 means error)
//  }
//  else
//  {
//      push(&btn, 10);
//  }
//  OSSemPost(&App_Semaphore_Spd,    /* Pointer to user-allocated semaphore.    */
//             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
//            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB1_PIN);
  OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
              LASER,            /*   Application Flag B bitmask.              */
              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
             &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
