/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include "app.h"
#include "blink.h"
#include "os.h"
#include "glib.h"
#include "dmd.h"
//#include "sl_board_control.h"
//#include "sl_simple_button_instances.h"

static bool btn0press = false;
static bool btn1press = false;
static bool cap_state = false;
static int cap_count = 0;
static bool cap_valid = false;

static OS_TCB tcb_new_hm;
static CPU_STK stack_new_hm[NEW_HM_TASK_STACK_SIZE];
static OS_TCB tcb_direction;
static CPU_STK stack_direction[DIRECTION_TASK_STACK_SIZE];
static OS_TCB tcb_monitor;
static CPU_STK stack_monitor[MONITOR_TASK_STACK_SIZE];
static OS_TCB tcb_physics;
static CPU_STK stack_physics[PHYSICS_TASK_STACK_SIZE];
static OS_TCB tcb_led_pwm;
static CPU_STK stack_led_pwm[LED_PWM_TASK_STACK_SIZE];
static OS_TCB tcb_led;
static CPU_STK stack_led[LED_TASK_STACK_SIZE];
static OS_TCB tcb_lcd;
static CPU_STK stack_lcd[LCD_TASK_STACK_SIZE];
static OS_TCB tcb_idle;
static CPU_STK stack_idle[IDLE_TASK_STACK_SIZE];

static OS_FLAG_GRP  App_Flags1;
//static OS_FLAG_GRP  App_Flags2;
//static OS_TMR  App_Timer;
//static OS_SEM  App_Semaphore_Spd;
//static OS_SEM  App_Semaphore_Dir;
static OS_MUTEX  App_Mutex1;
static OS_MUTEX  App_Mutex2;
static void new_hm_task(void *arg);
static void physics_task(void *arg);
static void direction_task(void *arg);
static void monitor_task(void *arg);
static void led_pwm_task(void *arg);
static void led_task(void *arg);
static void lcd_task(void *arg);
static void idle_task(void *arg);


/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
  gpio_open();
  //blink_init();
  lab2_init();
}
void App_TimerCallback(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
//  OSSemPost(&App_Semaphore_Dir,    /* Pointer to user-allocated semaphore.    */
//             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
//            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void lab2_init(void)
{
  RTOS_ERR err;

  // Create Blink Task
  OSTaskCreate(&tcb_idle,
               "idle task",
                idle_task,
                DEF_NULL,
                IDLE_TASK_PRIO,
               &stack_idle[0],
                (IDLE_TASK_STACK_SIZE / 10u),
                IDLE_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_new_hm,
               "NEW HM Task",
                new_hm_task,
                DEF_NULL,
                NEW_HM_TASK_PRIO,
               &stack_new_hm[0],
                (NEW_HM_TASK_STACK_SIZE / 10u),
                NEW_HM_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_physics,
               "Physics Task",
                physics_task,
                DEF_NULL,
                PHYSICS_TASK_PRIO,
               &stack_physics[0],
                (PHYSICS_TASK_STACK_SIZE / 10u),
                PHYSICS_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_direction,
               "Platform Direction Task",
                direction_task,
                DEF_NULL,
                PLATFORM_DIRECTION_TASK_PRIO,
               &stack_direction[0],
                (DIRECTION_TASK_STACK_SIZE / 10u),
                DIRECTION_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_monitor,
               "Collision Monitor Task",
                monitor_task,
                DEF_NULL,
                COLLISION_MONITOR_TASK_PRIO,
               &stack_monitor[0],
                (MONITOR_TASK_STACK_SIZE / 10u),
                MONITOR_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_led_pwm,
                 "led pwm control task",
                 led_pwm_task,
                  DEF_NULL,
                  LED_PWM_TASK_PRIO,
                 &stack_led_pwm[0],
                  (LED_PWM_TASK_STACK_SIZE / 10u),
                  LED_PWM_TASK_STACK_SIZE,
                  0u,
                  0u,
                  DEF_NULL,
                  (OS_OPT_TASK_STK_CLR),
                 &err);
  OSTaskCreate(&tcb_led,
               "led task",
               led_task,
                DEF_NULL,
                LED_TASK_PRIO,
               &stack_led[0],
                (LED_TASK_STACK_SIZE / 10u),
                LED_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_lcd,
               "lcd task",
               lcd_task,
                DEF_NULL,
                LCD_TASK_PRIO,
               &stack_lcd[0],
                (LCD_TASK_STACK_SIZE / 10u),
                LCD_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
//  OSTmrCreate(&App_Timer,                 /*   Pointer to user-allocated timer.         */
//              "App Timer",                /*   Name used for debugging.                 */
//               0,                         /*     0 initial delay.                       */
//               5,                       /*   100 Timer Ticks period.                  */
//               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
//               App_TimerCallback,         /*   Called when timer expires.               */
//               DEF_NULL,                  /*   No arguments to callback.                */
//              &err);
  OSFlagCreate(&App_Flags1,                /*   Pointer to user-allocated event flag.    */
               "App Flags1",               /*   Name used for debugging.                 */
                0,                        /*   Initial flags, all cleared.              */
               &err);
//  OSFlagCreate(&App_Flags2,                /*   Pointer to user-allocated event flag.    */
//               "App Flags2",               /*   Name used for debugging.                 */
//                0,                        /*   Initial flags, all cleared.              */
//               &err);
//  OSSemCreate(&App_Semaphore_Spd,             /*   Pointer to user-allocated semaphore.     */
//              "App Semaphore Speed",            /*   Name used for debugging.                 */
//               0,                         /*   Initial count: available in this case.   */
//              &err);
//  OSSemCreate(&App_Semaphore_Dir,             /*   Pointer to user-allocated semaphore.     */
//              "App Semaphore Direction",            /*   Name used for debugging.                 */
//               0,                         /*   Initial count: available in this case.   */
//              &err);
  OSMutexCreate(&App_Mutex1,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex1",  /*   Name used for debugging.                         */
                &err);
  OSMutexCreate(&App_Mutex2,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex2",  /*   Name used for debugging.                         */
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
static void idle_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    while (1)
    {
        EMU_EnterEM1();
    }
}
static void new_hm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OS_FLAGS flags;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        flags = OSFlagPend(&App_Flags1,        /*   Pointer to user-allocated event flag. */
                            RESET_HM,            /*   Flag bitmask to match.                */
                            0,                      /*   Wait for 100 OS Ticks maximum.        */
                            OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                            OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                            OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                            DEF_NULL,                 /*   Timestamp is not used.                */
                           &err);
    }
}
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
    }
}
static void direction_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    CAPSENSE_Init();
    RTOS_ERR err;
//    int prev_cap_count = 0;
//    int time_count = 1;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        read_capsense();
        if(cap_valid)
        {
            if(cap_count == 0b1100 || cap_count == 0b0011)
            {
                cap_count = cap_count & 0b1001;
            }
        }
//        if(prev_cap_count == cap_count)
//        {
//            time_count++;
//        }
//        else
//        {
//            time_count = 1;
//            prev_cap_count = cap_count;
//        }
//        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                     DEF_NULL,              /*   Timestamp is not used.                   */
//                    &err);
//        direction_data.direction = cap_count;
//        direction_data.time_count = time_count;
//        direction_data.straight = !cap_valid;
//        if(cap_state && cap_valid)
//        {
//            (direction_data.left_turns)++;
//        }
//        else if(!cap_state && cap_valid)
//        {
//            (direction_data.right_turns)++;
//        }
//        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                    &err);

//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}
static void monitor_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
    }
}
static void led_pwm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
    }
}
static void led_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    while (1)
    {
        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//        if(flags == 1) //btn task
//        {
//            OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            speed_result = speed_data;
//            OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            direction_result = direction_data;
//            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//            if(speed_result.mph >= 75 || (speed_result.mph >= 45 && !direction_result.straight)) //btn 0 press
//            {
//                      GPIO_PinOutSet(LED0_port, LED0_pin);
//            }
//            else
//            {
//                GPIO_PinOutClear(LED0_port, LED0_pin);
//            }
//        }
//        if(flags == 2) //slider task
//        {
//            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            direction_result = direction_data;
//            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//            if(direction_result.time_count == 25) //left slider press
//            {
//                GPIO_PinOutSet(LED1_port, LED1_pin);
//            }
//            else
//            {
//                GPIO_PinOutClear(LED1_port, LED1_pin);
//            }
//        }
    }
}
static void lcd_task(void *arg)
    {
        PP_UNUSED_PARAM(arg);
        RTOS_ERR err;
        uint32_t status;
        GLIB_Context_t glibContext;
        int currentLine = 0;
        /* Enable the memory lcd */
        status = sl_board_enable_display();
        EFM_ASSERT(status == SL_STATUS_OK);

        /* Initialize the DMD support for memory lcd display */
        status = DMD_init(0);
        EFM_ASSERT(status == DMD_OK);

        /* Initialize the glib context */
        status = GLIB_contextInit(&glibContext);
        EFM_ASSERT(status == GLIB_OK);

        glibContext.backgroundColor = White;
        glibContext.foregroundColor = Black;

        /* Fill lcd with background color */
        GLIB_clear(&glibContext);

        /* Use Narrow font */
        GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);
        while (1)
        {
            OSTimeDly(100, OS_OPT_TIME_DLY, &err);
//            OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            speed_result = speed_data;
//            OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
//                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
//                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
//                         DEF_NULL,              /*   Timestamp is not used.                   */
//                        &err);
//            direction_result = direction_data;
//            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
//                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
//                        &err);
//                    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//                    GLIB_clear(&glibContext);
//                    if(currentLine == 12)
//                    {
//                        currentLine = 0;
//                    }
//                    char string[100];
//                    sprintf(string, "%d MPH", speed_result.mph);
//                    const char * str1 = string;
//                    GLIB_drawStringOnLine(&glibContext,
//                                           str1,
//                                           currentLine,
//                                           GLIB_ALIGN_LEFT,
//                                           0,
//                                           5,
//                                           true);
//                    if(direction_result.straight)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                              "straight",
//                                              currentLine,
//                                              GLIB_ALIGN_RIGHT,
//                                              0,
//                                              5,
//                                              true);
//                    }
//                    else if(direction_result.direction == 0b0010)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                              "left",
//                                              currentLine,
//                                              GLIB_ALIGN_RIGHT,
//                                              0,
//                                              5,
//                                              true);
//                    }
//                    else if(direction_result.direction == 0b0001)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "hard left",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
//                    else if(direction_result.direction == 0b0100)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "right",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
//                    else if(direction_result.direction == 0b1000)
//                    {
//                        GLIB_drawStringOnLine(&glibContext,
//                                               "hard right",
//                                               currentLine,
//                                               GLIB_ALIGN_RIGHT,
//                                               0,
//                                               5,
//                                               true);
//                    }
                    DMD_updateDisplay();
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }

/***************************************************************************//**
 * @brief
 *   samples pushbutton 0 and sets btn0press to true if button 0 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button0(void)
{
  btn0press = !GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN);
}
/***************************************************************************//**
 * @brief
 *   samples pushbutton 1 and sets btn1press to true if button 1 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button1(void)
{
  btn1press = !GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN);
}
/***************************************************************************//**
 * @brief
 *   Determines the position of a finger on the capacitive touch slider by setting
 *   cap_state to true if the left side is pressed, false if the right side is
 *   pressed, and cap_valid to false if neither or both sides are touched (true if
 *   only one side).
 ******************************************************************************/
void read_capsense(void)
{
  cap_count = 0;
  CAPSENSE_Sense();
  for(int i = 0; i < 4; i++)
  {
      cap_count += CAPSENSE_getPressed(i) << i;
  }
  cap_valid = true;
  if((cap_count >= 4) && (cap_count % 4 == 0))
  {
      cap_state = false; //right

  }
  else if((cap_count < 4) && (cap_count > 0))
  {
      cap_state = true; //left
  }
  else //no press or both sides pressed
  {
      cap_valid = false;
  }
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB0_PIN);
//  if(is_empty(&btn))
//  {
//      btn = create_queue(10); //10 means btn 0 press (0 means error)
//  }
//  else
//  {
//      push(&btn, 10);
//  }
//  OSSemPost(&App_Semaphore_Spd,    /* Pointer to user-allocated semaphore.    */
//             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
//            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB1_PIN);
  OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
              LASER,            /*   Application Flag B bitmask.              */
              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
             &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
