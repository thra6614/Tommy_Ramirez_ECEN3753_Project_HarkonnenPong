/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include "app.h"
#include "blink.h"
#include "os.h"
#include "glib.h"
#include "dmd.h"
#include "math.h"
//#include "sl_board_control.h"
//#include "sl_simple_button_instances.h"

static bool btn0press = false;
static bool btn1press = false;
static bool cap_state = false;
static int cap_count = 0;
static bool cap_valid = false;

static OS_TCB tcb_new_hm;
static CPU_STK stack_new_hm[NEW_HM_TASK_STACK_SIZE];
static OS_TCB tcb_direction;
static CPU_STK stack_direction[DIRECTION_TASK_STACK_SIZE];
static OS_TCB tcb_monitor;
static CPU_STK stack_monitor[MONITOR_TASK_STACK_SIZE];
static OS_TCB tcb_physics;
static CPU_STK stack_physics[PHYSICS_TASK_STACK_SIZE];
static OS_TCB tcb_led_pwm;
static CPU_STK stack_led_pwm[LED_PWM_TASK_STACK_SIZE];
static OS_TCB tcb_led;
static CPU_STK stack_led[LED_TASK_STACK_SIZE];
static OS_TCB tcb_lcd;
static CPU_STK stack_lcd[LCD_TASK_STACK_SIZE];
static OS_TCB tcb_idle;
static CPU_STK stack_idle[IDLE_TASK_STACK_SIZE];

static OS_FLAG_GRP  App_Flags1;
static OS_FLAG_GRP  App_Flags2;
static OS_TMR  App_Timer_LCD;
static OS_TMR  App_Timer_Physics;
static OS_TMR  App_Timer_Slider;
static OS_TMR  App_Timer_PWM;
static OS_SEM  App_Semaphore_LCD;
static OS_SEM  App_Semaphore_Physics;
static OS_SEM  App_Semaphore_Slider;
static OS_SEM  App_Semaphore_PWM;

static OS_MUTEX  App_Mutex1;
static OS_MUTEX  App_Mutex2;
static OS_MUTEX  App_Mutex3;
static void new_hm_task(void *arg);
static void physics_task(void *arg);
static void direction_task(void *arg);
static void monitor_task(void *arg);
static void led_pwm_task(void *arg);
static void led_task(void *arg);
static void lcd_task(void *arg);
static void idle_task(void *arg);

struct init_variables var_init = {4, // Data Structure Version
                                  10, // TauPhysics [ms]
                                  150, // TauLCD [ms]
                                  9800, // Gravity [mm/s^2]
                                  100000, // CanyonSize [cm]
                                  { // HoltzmanMasses
                                    3, // Num [-]
                                    10000, // DisplayDiameter [cm]
                                    0, // InitialConditions [enum: Fixed=0.  127+ are available for user-defined modes]
                                    { // (signed) InitialVelocity
                                      4000, // xvel [cm/s]
                                      0 // yvel [cm/s]
                                    },
                                    0, // (signed) InitialHorizontalPosition [mm]
                                    {0,0,0,0,0,0,0,0} // UserDefinedModeInput[0..7] (all “don’t care” for InitialConditions=0)
                                  },
                                  { // Platform
                                    20000000, // MaxForce [N]
                                    100, // Mass [kg]
                                    15000, // Length [cm]
                                    { // BounceFronCanyonWalls
                                      true, // Enabled [T/F]
                                      false, // Limited [T/F]
                                      0 // MaxPlatformBounceSpeed [cm/s] (“don’t care” for Limited=FALSE)
                                    },
                                    false // Automatic Control [T/F]
                                  },
                                  { // HoltzmanShield
                                    1000, // MinimumEffectivePerpendicularSpeed [cm/s]
                                    70, // ExclusivelyPassiveBounceKineticEnergyReduction[%]
                                    { // Boost
                                      40, // KineticEnergyIncrease[%]
                                      500, // ArmingWindowBeforeImpact[ms]
                                      1000 // RechargeTimeAfterDisarm[ms]
                                    }
                                  },
                                  { // Laser
                                    1, // NumActivations [-]
                                    false // Automatic Control [T/F]
                                  }
                                 };
struct object_t platform = {64000, 0, 0, 0, 100, 0, true};
struct object_t HM = {50000, 0, 0, 0, 0, 0, false};
bool shield = false;
int hm_refill;
/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
  gpio_open();
  //blink_init();

  default_init();
  lab_init();
}
void default_init(void)
{
  platform.mass = var_init.Plat.mass;
  platform.ypos = 100000;
  HM.xpos = var_init.HM.initx + (64000 - var_init.canyonsize/2) + var_init.HM.DisplayDiameter/2;
  HM.mass = var_init.Plat.mass;
  HM.force = var_init.gravity;
  HM.xvel = var_init.HM.initial_velocity.xvel;
  HM.yvel = var_init.HM.initial_velocity.yvel;
  hm_refill = var_init.HM.Num;
}
void App_TimerCallbackPhysics(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_Physics,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void App_TimerCallbackLCD(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_LCD,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void App_TimerCallbackPWM(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_PWM,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void App_TimerCallbackSlider(void  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&App_Semaphore_Slider,    /* Pointer to user-allocated semaphore.    */
             OS_OPT_POST_1,    /* Only wake up highest-priority task.     */
            &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
void lab_init(void)
{
  RTOS_ERR err;

  // Create Blink Task
  OSTaskCreate(&tcb_idle,
               "idle task",
                idle_task,
                DEF_NULL,
                IDLE_TASK_PRIO,
               &stack_idle[0],
                (IDLE_TASK_STACK_SIZE / 10u),
                IDLE_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_new_hm,
               "NEW HM Task",
                new_hm_task,
                DEF_NULL,
                NEW_HM_TASK_PRIO,
               &stack_new_hm[0],
                (NEW_HM_TASK_STACK_SIZE / 10u),
                NEW_HM_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_physics,
               "Physics Task",
                physics_task,
                DEF_NULL,
                PHYSICS_TASK_PRIO,
               &stack_physics[0],
                (PHYSICS_TASK_STACK_SIZE / 10u),
                PHYSICS_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_direction,
               "Platform Direction Task",
                direction_task,
                DEF_NULL,
                PLATFORM_DIRECTION_TASK_PRIO,
               &stack_direction[0],
                (DIRECTION_TASK_STACK_SIZE / 10u),
                DIRECTION_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_monitor,
               "Collision Monitor Task",
                monitor_task,
                DEF_NULL,
                COLLISION_MONITOR_TASK_PRIO,
               &stack_monitor[0],
                (MONITOR_TASK_STACK_SIZE / 10u),
                MONITOR_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OSTaskCreate(&tcb_led_pwm,
                 "led pwm control task",
                 led_pwm_task,
                  DEF_NULL,
                  LED_PWM_TASK_PRIO,
                 &stack_led_pwm[0],
                  (LED_PWM_TASK_STACK_SIZE / 10u),
                  LED_PWM_TASK_STACK_SIZE,
                  0u,
                  0u,
                  DEF_NULL,
                  (OS_OPT_TASK_STK_CLR),
                 &err);
  OSTaskCreate(&tcb_led,
               "led task",
               led_task,
                DEF_NULL,
                LED_TASK_PRIO,
               &stack_led[0],
                (LED_TASK_STACK_SIZE / 10u),
                LED_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTaskCreate(&tcb_lcd,
               "lcd task",
               lcd_task,
                DEF_NULL,
                LCD_TASK_PRIO,
               &stack_lcd[0],
                (LCD_TASK_STACK_SIZE / 10u),
                LCD_TASK_STACK_SIZE,
                0u,
                0u,
                DEF_NULL,
                (OS_OPT_TASK_STK_CLR),
               &err);
  OSTmrCreate(&App_Timer_Physics,                 /*   Pointer to user-allocated timer.         */
              "App Timer Physics",                /*   Name used for debugging.                 */
               var_init.TauPhysics/10,               /*     initial delay.                       */
               var_init.TauPhysics/10,               /*   10 Timer Ticks period.                  */
               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
               App_TimerCallbackPhysics,         /*   Called when timer expires.               */
               DEF_NULL,                  /*   No arguments to callback.                */
              &err);
  OSTmrCreate(&App_Timer_LCD,                 /*   Pointer to user-allocated timer.         */
              "App Timer LCD",                /*   Name used for debugging.                 */
               var_init.TauLCD/10,               /*     initial delay.                       */
               var_init.TauLCD/10,               /*   10 Timer Ticks period.                  */
               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
               App_TimerCallbackLCD,         /*   Called when timer expires.               */
               DEF_NULL,                  /*   No arguments to callback.                */
              &err);
  OSTmrCreate(&App_Timer_Slider,                 /*   Pointer to user-allocated timer.         */
              "App Timer Slider",                /*   Name used for debugging.                 */
               0,               /*     initial delay.                       */
               50,               /*   10 Timer Ticks period.                  */
               OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
               App_TimerCallbackSlider,         /*   Called when timer expires.               */
               DEF_NULL,                  /*   No arguments to callback.                */
              &err);
  OSTmrCreate(&App_Timer_PWM,                 /*   Pointer to user-allocated timer.         */
                "App Timer PWM",                /*   Name used for debugging.                 */
                 0,               /*     initial delay.                       */
                 10,               /*   10 Timer Ticks period.                  */
                 OS_OPT_TMR_PERIODIC,       /*   Timer is periodic.                       */
                 App_TimerCallbackPWM,         /*   Called when timer expires.               */
                 DEF_NULL,                  /*   No arguments to callback.                */
                &err);
  OSFlagCreate(&App_Flags1,                /*   Pointer to user-allocated event flag.    */
               "App Flags1",               /*   Name used for debugging.                 */
                0,                        /*   Initial flags, all cleared.              */
               &err);
  OSFlagCreate(&App_Flags2,                /*   Pointer to user-allocated event flag.    */
               "App Flags2",               /*   Name used for debugging.                 */
                0,                        /*   Initial flags, all cleared.              */
               &err);
  OSSemCreate(&App_Semaphore_LCD,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore LCD",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSSemCreate(&App_Semaphore_Physics,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore Physics",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSSemCreate(&App_Semaphore_Slider,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore Slider",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSSemCreate(&App_Semaphore_PWM,             /*   Pointer to user-allocated semaphore.     */
              "App Semaphore PWM",            /*   Name used for debugging.                 */
               0,                         /*   Initial count: available in this case.   */
              &err);
  OSMutexCreate(&App_Mutex1,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex1",  /*   Name used for debugging.                         */
                &err);
  OSMutexCreate(&App_Mutex2,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex2",  /*   Name used for debugging.                         */
                &err);
  OSMutexCreate(&App_Mutex3,   /*   Pointer to user-allocated mutex.                 */
                "App Mutex3",  /*   Name used for debugging.                         */
                &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
static void idle_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    while (1)
    {
        EMU_EnterEM1();
    }
}
static void new_hm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OS_FLAGS flags;
    int refill = var_init.HM.Num;
    int laser_ammo = var_init.laser.NumActivations;
    while (1)
    {
//        OSTimeDly(100, OS_OPT_TIME_DLY, &err);
        flags = OSFlagPend(&App_Flags1,        /*   Pointer to user-allocated event flag. */
                            RESET_HM,            /*   Flag bitmask to match.                */
                            0,                      /*   Wait for 100 OS Ticks maximum.        */
                            OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                            OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                            OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                            DEF_NULL,                 /*   Timestamp is not used.                */
                           &err);

        OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        if(flags & LASER)
        {
            if(laser_ammo > 0)
            {
                laser_ammo--;
                reset_hm(&HM, &refill);
            }
        }
        else if(refill > 0)
        {
          reset_hm(&HM, &refill);
        }
        OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                             OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                            &err);
        OSMutexPend(&App_Mutex3,             /*   Pointer to user-allocated mutex.         */
                                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                                     DEF_NULL,              /*   Timestamp is not used.                   */
                                    &err);
        hm_refill = refill;
        OSMutexPost(&App_Mutex3,         /*   Pointer to user-allocated mutex.         */
                             OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                            &err);
    }
}
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    OSTmrStart(&App_Timer_Physics,                  /*   Pointer to user-allocated timer.         */
               &err);
    struct object_t HM_Phys;
    struct object_t Plat_Phys;
    struct object_t Old_HM;
    bool shield_phys;
    bool change = true;
    int refill;
    while (1)

    {
        OSSemPend(&App_Semaphore_Physics,                 /* Pointer to user-allocated semaphore.    */
                   0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                   OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                   DEF_NULL,                      /* Timestamp is not used.                  */
                  &err);
        OSFlagPost(&App_Flags2,             /*   Pointer to user-allocated event flag.    */
                    PHYSICS_TICK,            /*   Application Flag B bitmask.              */
                    OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
                    &err);
        OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        HM_Phys = HM;
        OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                      0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                      OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                      DEF_NULL,              /*   Timestamp is not used.                   */
                     &err);
        Plat_Phys = platform;
        shield_phys = shield;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        Old_HM = HM_Phys;
        physics(&HM_Phys, 0, HM_Phys.force, 0);
        physics(&Plat_Phys, Plat_Phys.force, 0, 0);
        bounds(&Plat_Phys, var_init.canyonsize);
        bounds(&HM_Phys, var_init.canyonsize);
        OSMutexPend(&App_Mutex3,             /*   Pointer to user-allocated mutex.         */
                                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                                     DEF_NULL,              /*   Timestamp is not used.                   */
                                    &err);
        refill = hm_refill;
        OSMutexPost(&App_Mutex3,         /*   Pointer to user-allocated mutex.         */
                             OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                            &err);
        if((HM_Phys.xpos > Plat_Phys.xpos - var_init.Plat.length/2) && (HM_Phys.xpos < Plat_Phys.xpos + var_init.Plat.length/2))
        {
            if(HM_Phys.ypos  + var_init.HM.DisplayDiameter > 100000 && Old_HM.ypos  + var_init.HM.DisplayDiameter <= 100000 && HM_Phys.yvel > var_init.shield.minspeed)
            {
                HM_Phys.ypos = 100000;
                if(!shield_phys)
                {
                    physics(&HM_Phys, 0, 0, var_init.shield.KEreduction);
                }
                else
                {
                  physics(&HM_Phys, 0, 0, 100 + var_init.shield.boost.KEincrease);
                  OSFlagPost(&App_Flags2,             /*   Pointer to user-allocated event flag.    */
                              STOP,            /*   Application Flag B bitmask.              */
                              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
                              &err);
                }
            }
        }
        if(HM_Phys.ypos/1000 >= 123 && var_init.laser.Auto && refill > 0)
        {
            OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
                          LASER,            /*   Application Flag B bitmask.              */
                          OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
                         &err);
            change = false;
        }
        else if(HM_Phys.ypos/1000 >= 123)
          {
            OSMutexPend(&App_Mutex3,             /*   Pointer to user-allocated mutex.         */
                                   0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                                   OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                                   DEF_NULL,              /*   Timestamp is not used.                   */
                                  &err);
                      hm_refill = -7;
                      OSMutexPost(&App_Mutex3,         /*   Pointer to user-allocated mutex.         */
                                   OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                                  &err);
          }
        if(HM_Phys.ypos/1000 <= -10 && refill > 0)
        {
            OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
                        BOUNDS,            /*   Application Flag B bitmask.              */
                        OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
                       &err);
            change = false;
        }
        else if(HM_Phys.ypos/1000 <= -10 || refill == 0)
                {
        OSMutexPend(&App_Mutex3,             /*   Pointer to user-allocated mutex.         */
                               0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                               OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                               DEF_NULL,              /*   Timestamp is not used.                   */
                              &err);
                  hm_refill = -9;
                  OSMutexPost(&App_Mutex3,         /*   Pointer to user-allocated mutex.         */
                               OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                              &err);
                }
        if(change)
        {
          OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                       0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                       OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                       DEF_NULL,              /*   Timestamp is not used.                   */
                      &err);
          HM = HM_Phys;
          OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                       OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                      &err);
        }
        change = true;
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        platform = Plat_Phys;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

    }
}
static void direction_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    CAPSENSE_Init();
    RTOS_ERR err;
    OSTmrStart(&App_Timer_Slider,                  /*   Pointer to user-allocated timer.         */
               &err);
    while (1)
    {
        OSSemPend(&App_Semaphore_Slider,                 /* Pointer to user-allocated semaphore.    */
                   0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                   OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                   DEF_NULL,                      /* Timestamp is not used.                  */
                  &err);
        read_capsense();
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        platform.force = cap_count;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);

        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}
static void monitor_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    OS_FLAGS flags;
    RTOS_ERR err;
    while (1)
    {
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        shield = false;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        flags = OSFlagPend(&App_Flags2,        /*   Pointer to user-allocated event flag. */
                            ACTIVATE,            /*   Flag bitmask to match.                */
                            0,                      /*   Wait for 100 OS Ticks maximum.        */
                            OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                            OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                            OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                            DEF_NULL,                 /*   Timestamp is not used.                */
                           &err);
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                             0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                             OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                             DEF_NULL,              /*   Timestamp is not used.                   */
                            &err);
        shield = true;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        for(int i = 0; i<var_init.shield.boost.ArmingWindow/var_init.TauPhysics; i++)
        {
            flags = OSFlagPend(&App_Flags2,        /*   Pointer to user-allocated event flag. */
                                SHIELD_COND,            /*   Flag bitmask to match.                */
                                0,                      /*   Wait for 100 OS Ticks maximum.        */
                                OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                                OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                                OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                                DEF_NULL,                 /*   Timestamp is not used.                */
                               &err);
            if(flags & ACTIVATE)
            {
                i = 0;
            }
            if(flags & STOP)
            {
                i = (var_init.shield.boost.ArmingWindow/var_init.TauPhysics) + 1;
            }
        }
    }
}
static void led_pwm_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
//    while (1)
//    {
//        OSTimeDly(1000, OS_OPT_TIME_DLY, &err);
//    }
}
static void led_task(void *arg)
{
    PP_UNUSED_PARAM(arg);
    RTOS_ERR err;
    int height = 0;
    int direction;
    int cycle = 0;
    int period = 1;
    int period2 = 1;
    int remainder;
    int remainder2;
    OSTmrStart(&App_Timer_PWM,                  /*   Pointer to user-allocated timer.         */
               &err);
    struct object_t HM_led;
    struct object_t Plat_led;
    float needed_F;
    while (1)
    {
        OSSemPend(&App_Semaphore_PWM,                 /* Pointer to user-allocated semaphore.    */
                   0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                   OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                   DEF_NULL,                      /* Timestamp is not used.                  */
                  &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        cycle++;

        if((height/1000 > 130) && (cycle % 10 == 0) && cycle > 0)
        {
            while(1)
              {
                for(int i = 0; i < 10; i++)
                {
                  OSSemPend(&App_Semaphore_PWM,                 /* Pointer to user-allocated semaphore.    */
                                   0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                                   OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                                   DEF_NULL,                      /* Timestamp is not used.                  */
                                  &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
                }
                GPIO_PinOutToggle(LED0_port, LED0_pin);
              }
        }
        else
        {
            OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
            height = HM.ypos;
            HM_led = HM;
            OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        }
        OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                     0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                     OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                     DEF_NULL,              /*   Timestamp is not used.                   */
                    &err);
        direction = platform.force;
        Plat_led = platform;
        OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                    &err);
        needed_F = calc_rled_pwm(Plat_led.mass, var_init.Plat.MaxForce, HM_led.xpos, HM_led.ypos, HM_led.xvel, HM_led.yvel, Plat_led.xpos, Plat_led.xvel, Plat_led.ypos, var_init.gravity);

        if(direction == 0) period = 30;
        else if(direction == 1) period = 1;
        else if(direction == 2) period = 10;
        else if(direction == 4) period = 10;
        else if(direction == 8) period = 1;
        remainder = cycle % (period+1);
        if(remainder == 0)
        {
          GPIO_PinOutToggle(LED1_port, LED1_pin);
          if (cycle >= 10000)
            {
              cycle = 0;
            }
        }
        if(needed_F < 0.05) period2 = 30; //no force needed
        else if(needed_F <= 0.25) period2 = 10; //some force needed
        else period2 = 1; //max force needed
        remainder2 = cycle % (period2+1);
        if(remainder2 == 0)
        {
          GPIO_PinOutToggle(LED0_port, LED0_pin);

        }
    }
}
static void lcd_task(void *arg)
    {
        PP_UNUSED_PARAM(arg);
        RTOS_ERR err;
        uint32_t status;
        GLIB_Context_t glibContext;
        //int currentLine = 0;
        /* Enable the memory lcd */
        status = sl_board_enable_display();
        EFM_ASSERT(status == SL_STATUS_OK);

        /* Initialize the DMD support for memory lcd display */
        status = DMD_init(0);
        EFM_ASSERT(status == DMD_OK);

        /* Initialize the glib context */
        status = GLIB_contextInit(&glibContext);
        EFM_ASSERT(status == GLIB_OK);

        glibContext.backgroundColor = White;
        glibContext.foregroundColor = Black;
        /* Fill lcd with background color */

        //static int slower = 0;
        //bool ledon = false;
        GLIB_clear(&glibContext);

        /* Use Narrow font */
        GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);
        int border = var_init.canyonsize;
        int plat_width = var_init.Plat.length;

        GLIB_Rectangle_t plat_dim;
        GLIB_Rectangle_t canyon;

        struct object_t Plat_LCD;
        struct object_t HM_LCD;
        HM_LCD.ypos = 0;
        int refill;
        OSTmrStart(&App_Timer_LCD,                  /*   Pointer to user-allocated timer.         */
                   &err);
        while (1)
        {
            OSSemPend(&App_Semaphore_LCD,                 /* Pointer to user-allocated semaphore.    */
                       0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                       OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                       DEF_NULL,                      /* Timestamp is not used.                  */
                      &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            OSMutexPend(&App_Mutex3,             /*   Pointer to user-allocated mutex.         */
                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                         DEF_NULL,              /*   Timestamp is not used.                   */
                        &err);
            refill = hm_refill;
            OSMutexPost(&App_Mutex3,         /*   Pointer to user-allocated mutex.         */
                                 OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                                &err);
            while(refill == -9)
            {
                OSSemPend(&App_Semaphore_LCD,                 /* Pointer to user-allocated semaphore.    */
                                       0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                                       OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                                       DEF_NULL,                      /* Timestamp is not used.                  */
                                      &err);
                GLIB_clear(&glibContext);
                GLIB_drawStringOnLine(&glibContext,
                                      "Winner Winner!",
                                        0,
                                        GLIB_ALIGN_LEFT,
                                        25,
                                        25,
                                        true);
                DMD_updateDisplay();
            }
            while(refill == -7)
            {
                OSSemPend(&App_Semaphore_LCD,                 /* Pointer to user-allocated semaphore.    */
                                       0,                             /* Wait for a maximum of 1000 OS Ticks.    */
                                       OS_OPT_PEND_BLOCKING,          /* Task will block.                        */
                                       DEF_NULL,                      /* Timestamp is not used.                  */
                                      &err);
                GLIB_clear(&glibContext);
                GLIB_drawStringOnLine(&glibContext,
                                      "Game Over. Run!",
                                       0,
                                       GLIB_ALIGN_LEFT,
                                       25,
                                       25,
                                       true);
                DMD_updateDisplay();
            }
            GLIB_clear(&glibContext);
            OSMutexPend(&App_Mutex1,             /*   Pointer to user-allocated mutex.         */
                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                         DEF_NULL,              /*   Timestamp is not used.                   */
                        &err);
            HM_LCD = HM;
            OSMutexPost(&App_Mutex1,         /*   Pointer to user-allocated mutex.         */
                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                        &err);
            OSMutexPend(&App_Mutex2,             /*   Pointer to user-allocated mutex.         */
                         0,                  /*   Wait for a maximum of 1000 OS Ticks.     */
                         OS_OPT_PEND_BLOCKING,  /*   Task will block.                         */
                         DEF_NULL,              /*   Timestamp is not used.                   */
                        &err);
            Plat_LCD = platform;
            OSMutexPost(&App_Mutex2,         /*   Pointer to user-allocated mutex.         */
                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                        &err);
            GLIB_drawCircleFilled(&glibContext, HM_LCD.xpos/1000, HM_LCD.ypos/1000, var_init.HM.DisplayDiameter/2000);
            canyon.xMin = 64-(border/2000);
            canyon.xMax = 0;
            canyon.yMin = 0;
            canyon.yMax = 128;
            GLIB_drawRectFilled(&glibContext, &canyon);

            canyon.xMin = 64+(border/2000);
            canyon.xMax = 128;
            GLIB_drawRectFilled(&glibContext, &canyon);
            plat_dim.xMin = Plat_LCD.xpos/1000 - plat_width/2000;
            plat_dim.xMax = Plat_LCD.xpos/1000 + plat_width/2000;
            plat_dim.yMin = Plat_LCD.ypos/1000;
            plat_dim.yMax = Plat_LCD.ypos/1000 + 1;
            GLIB_drawRectFilled(&glibContext, &plat_dim);
            DMD_updateDisplay();
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }

/***************************************************************************//**
 * @brief
 *   samples pushbutton 0 and sets btn0press to true if button 0 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button0(void)
{
  btn0press = !GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN);
}
/***************************************************************************//**
 * @brief
 *   samples pushbutton 1 and sets btn1press to true if button 1 is pressed and
 *   false if not pressed.
 ******************************************************************************/
void read_button1(void)
{
  btn1press = !GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN);
}
/***************************************************************************//**
 * @brief
 *   Determines the position of a finger on the capacitive touch slider by setting
 *   cap_state to true if the left side is pressed, false if the right side is
 *   pressed, and cap_valid to false if neither or both sides are touched (true if
 *   only one side).
 ******************************************************************************/
void read_capsense(void)
{
  cap_count = 0;
  CAPSENSE_Sense();
  for(int i = 0; i < 4; i++)
  {
      cap_count += ((CAPSENSE_getPressed(i) * 1) << i);
  }
  cap_valid = true;
  if((cap_count >= 4) && (cap_count % 4 == 0))
  {
      cap_state = false; //right

  }
  else if((cap_count < 4) && (cap_count > 0))
  {
      cap_state = true; //left
  }
  else //no press or both sides pressed
  {
      cap_valid = false;
  }
  if(cap_valid)
  {
      if(cap_count == 0b1100 || cap_count == 0b0011)
      {
          cap_count = cap_count & 0b1001;
      }
  }
}
void physics(struct object_t *object, int xaccelmode, int yaccel, float ke_change) {
    float millisec = 1000/var_init.TauPhysics;
    int max_accelx = (var_init.Plat.MaxForce/var_init.Plat.mass)*100; //cm/s^2
    max_accelx = max_accelx/500; //
    if(xaccelmode == 1)
    {
      object->xvel += max_accelx/100; //+ cm/s/tau
    }
    else if(xaccelmode == 2)
    {
      object->xvel += max_accelx/400;
    }
    else if(xaccelmode == 4)
    {
      object->xvel -= max_accelx/400;
    }
    else if(xaccelmode == 8)
    {
      object->xvel -= max_accelx/100;
    }
    if(ke_change == 0)
    {
      object->xpos += object->xvel/100; //pos in cm vel in cm/s adding cm/tau
      if(!object->plat_or_hm && object->ypos/1000 < 1500)
      {
        object->yvel += (yaccel/10)/millisec; //mm/s^2 to cm/s^2 then cm/s^2 to cm/s/tau
        object->ypos += object->yvel/10;
      }
    }
    else
    {
      float ke;
      float totalspeed;
      float angle;
      totalspeed = pow(pow(object->xvel/100, 2) + pow(object->yvel/100, 2), 0.5);
      ke = 0.5 * object->mass * pow(totalspeed,2);
      ke = ke * (ke_change / 100);
      int newtotalspeed = pow(ke/(0.5 * object->mass), 0.5)*100;
      angle = atan2(object->yvel, object->xvel);
      object->xvel = cos(angle)*newtotalspeed;
      object->yvel = -1 * sin(angle)*newtotalspeed;
    }
}
void bounds(struct object_t *object, int border){
  bool plat_hm = object->plat_or_hm;
  bool bounce = false;
  if(plat_hm)
  {
      if((object->xpos + var_init.Plat.length/2) > (64000+(border/2)))
      {
          object->xpos = 64000+(border/2) - var_init.Plat.length/2;
          if(object->xvel > 0)
          {
              bounce = true;
          }
      }
      else if((object->xpos - var_init.Plat.length/2) < (64000-(border/2)))
      {
          object->xpos = 64000-(border/2) + var_init.Plat.length/2;
          if(object->xvel < 0)
          {
              bounce = true;
          }
      }
      if(bounce == true)
      {
        if(!var_init.Plat.MaxSpeed.enable)
        {
            object->xvel = 0;
        }
        else if(var_init.Plat.MaxSpeed.limited)
        {
            if(var_init.Plat.MaxSpeed.MaxPlatformBounceSpeed != 0 || abs(object->xvel) > var_init.Plat.MaxSpeed.MaxPlatformBounceSpeed)
            {
                if(object->xpos > 64000)
                {
                    object->xvel = var_init.Plat.MaxSpeed.MaxPlatformBounceSpeed;
                }
                else
                {
                    object->xvel = (-1) * var_init.Plat.MaxSpeed.MaxPlatformBounceSpeed;
                }
            }
        }
        object->xvel *= (-1);
      }
  }
  else
  {
      if((object->xpos + var_init.HM.DisplayDiameter/2) > (64000+(border/2)))
      {
          object->xpos = 64000+(border/2) - var_init.HM.DisplayDiameter/2;
          if(object->xvel > 0)
          {
              bounce = true;
          }
      }
      else if((object->xpos - var_init.HM.DisplayDiameter/2) < (64000-(border/2)))
      {
          object->xpos = 64000-(border/2) + var_init.HM.DisplayDiameter/2;
          if(object->xvel < 0)
          {
              bounce = true;
          }
      }
      if(bounce == true)
      {
          object->xvel *= (-1);
      }
    }
}

void reset_hm(struct object_t *object, int *hm_count) {
    (*hm_count)--;
    object->ypos = 0;
    object->yvel = 0;
    object->xvel = var_init.HM.initial_velocity.xvel;
}
float calc_rled_pwm(float mass, float max_force, float hm_x_init, float hm_y_init, float hm_x_vel, float hm_y_vel, float plat_x_init, float plat_x_vel, float fin_y, float gravity)
{
  float time = calc_time((hm_y_init - fin_y), hm_y_vel, gravity/10);
  float x_final = hm_x_vel*time + hm_x_init;
  float del_x = x_final - plat_x_init;
  float accel = (-2*(time*plat_x_vel-abs(del_x))) / (time * time);
  float new_force = (mass*accel);
  float force_fraction = new_force / max_force;
  return abs(force_fraction);
}

float calc_time(float del_y, float vel, float gravity)
{
  float vfinal = sqrt(((vel/100) * (vel/100) + 2*(gravity/100)*abs((del_y/100))))*100;
  float totalaccel =  vfinal - vel;
  float time_to_impact =  totalaccel / gravity;
  return time_to_impact/10;
}
/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB0_PIN);
  if(!GPIO_PinInGet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN))
  {
    OSFlagPost(&App_Flags2,             /*   Pointer to user-allocated event flag.    */
                ACTIVATE,            /*   Application Flag B bitmask.              */
                OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
               &err);
  }
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BSP_GPIO_PB1_PIN);
  if(!GPIO_PinInGet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN))
    {
  OSFlagPost(&App_Flags1,             /*   Pointer to user-allocated event flag.    */
              LASER,            /*   Application Flag B bitmask.              */
              OS_OPT_POST_FLAG_SET,  /*   Set the flag.                            */
             &err);
    }
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}
